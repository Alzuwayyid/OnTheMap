//
//  LogInViewController.swift
//  OntheMap
//
//  Created by MUHAMMED ZOYED on 7/9/20.
//  Copyright © 2020 Udacity. All rights reserved.
//

import UIKit

class LogInViewController: UIViewController {

    @IBOutlet weak var Email: UITextField!
    @IBOutlet weak var Password: UITextField!
    @IBOutlet weak var Login: UIButton!
    @IBOutlet weak var logButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()

    }
    
    @IBAction func Loggin(_ sender: Any) {
        let myEmail = Email.text
        let myPass = Password.text
        
        if (myEmail!.isEmpty) || (myPass!.isEmpty){
            let alert = UIAlertController(title: "error", message: "Email and password must contain data", preferredStyle: .alert)
            
            alert.addAction(UIAlertAction(title: "Okay", style: .default, handler: {_ in return }))
            
            self.present(alert, animated: true, completion: nil)
        }
        else {
            API.login(myEmail, myPass){(success, key, error) in
                DispatchQueue.main.async{
                    if error != nil {
                            let alert = UIAlertController(title: "Erorr", message: "Failed Request", preferredStyle: .alert )
                            alert.addAction(UIAlertAction (title: "OK", style: .default, handler: { _ in
                                return
                            }))
                            self.present(alert, animated: true, completion: nil)
                            return
                        }
                    if !success{
                            let alert = UIAlertController(title: "Erorr", message: "Password or Email uncorrect", preferredStyle: .alert )
                            alert.addAction(UIAlertAction (title: "Okay", style: .default, handler: { _ in
                                return
                            }))
                            self.present(alert, animated: true, completion: nil)
                        } else {
                            print("Success Request")
                            if let TabBar = self.storyboard?.instantiateViewController(withIdentifier: "TabBar") {
                                self.present(TabBar, animated: true, completion: nil)}
                        }
            }
        }
    }

    



}
}
