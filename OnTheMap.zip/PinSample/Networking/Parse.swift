//
//  Parse.swift
//  OntheMap
//
//  Created by MUHAMMED ZOYED on 7/12/20.
//  Copyright © 2020 Udacity. All rights reserved.
//

import Foundation

class Parse: NSObject {
    class func sharedInstance() -> Parse {
        struct Singleton {
            static var sharedInstance = Parse()
        }
        return Singleton.sharedInstance
    }
    
    func getStudentLocations(completion: @escaping (_ result: [StudentLoc]?, _ success: Bool, _ error: String?) -> Void){
        
        var request = URLRequest(url: URL(string: "https://onthemap-api.udacity.com/v1/StudentLocation?order=-updatedAt")!)

        let session = URLSession.shared
        let task = session.dataTask(with: request) { data, response, error in
            if error != nil { // Handle error...
                completion(nil, false, "Error in Network")
                return
            }
            
            print(String(data: data!, encoding: .utf8)!)
            guard let statusCode = (response as? HTTPURLResponse)?.statusCode else {
                _ = NSError(domain: NSURLErrorDomain, code: 0, userInfo: nil)
                completion (nil, false,"")
                return
            }
            
            if statusCode >= 200 && statusCode < 300 {
                let jsonObject = try! JSONSerialization.jsonObject(with: data!, options: [])
                guard let jsonDictionary = jsonObject as? [String : Any] else {return}
                let resultsArray = jsonDictionary["results"] as? [[String:Any]]
                
                guard let array = resultsArray else {return}
                let dataObject = try! JSONSerialization.data(withJSONObject: array, options: .prettyPrinted)
                let locations = try! JSONDecoder().decode([StudentLoc].self, from: dataObject)
                completion (locations, true, nil)
            }
        }
        task.resume()
        
    }
    
    func postStudentLocation(_ location: StudentLoc, completion: @escaping (_ success: Bool, _ error: String?) -> Void) {
        
        var request = URLRequest(url: URL(string: "https://onthemap-api.udacity.com/v1/StudentLocation")!)

        request.httpMethod = "POST"
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        
        let body: [String:Any] = [
            "uniqueKey": location.uniqueKey ?? " ",
            "firstName": location.firstName ?? "firstName",
            "lastName": location.lastName ?? "lastName",
            "mapString" :location.mapString!,
            "mediaURL": location.mediaURL!,
            "latitude": location.latitude!,
            "longitude":location.longitude!,
        ]
        let jsonData = try! JSONSerialization.data(withJSONObject: body, options: .prettyPrinted)
        request.httpBody = jsonData
        
        let session = URLSession.shared
        let task = session.dataTask(with: request as URLRequest) { (data, response, error) in
            guard(error == nil) else{
                completion(false, "error")
                return
            }
            guard let data = data else{
                completion(false, "error")
                return
            }
            print(String(data: data, encoding: .utf8)!)
            
            guard let statusCode = (response as? HTTPURLResponse)?.statusCode else {
                _ = NSError(domain: NSURLErrorDomain, code: 0, userInfo: nil)
                completion (false,"")
                return
            }
            
            if statusCode >= 200 && statusCode < 300 {
                let jsonObject = try! JSONSerialization.jsonObject(with: data, options: [])
                
                guard let jsonDictionary = jsonObject as? [String : Any] else {
                    completion (false, "error")
                    return
                }
                print(jsonDictionary)
                completion (true, nil)
            } else {
                completion(false, "error" )
            }
        }
        task.resume()
    }


    

}
