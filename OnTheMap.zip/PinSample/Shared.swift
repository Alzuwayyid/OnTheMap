//
//  Sharedata.swift
//  OntheMap
//
//  Created by MUHAMMED ZOYED on 15/07/2020.
//  Copyright © 2020 Udacity. All rights reserved.
//

import Foundation
class Data {
    static let shared = Data()
    var usersData = [Any?]()
    private init() { }
}
