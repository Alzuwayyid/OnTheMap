//
//  TableViewCell.swift
//  OntheMap
//
//  Created by MUHAMMED ZOYED on 15/07/2020.
//  Copyright © 2020 Udacity. All rights reserved.
//

import UIKit
import Foundation

class TableViewCell: UITableViewCell {

    @IBOutlet weak var icon: UIImageView!
    @IBOutlet weak var name: UILabel!
    @IBOutlet weak var url: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
