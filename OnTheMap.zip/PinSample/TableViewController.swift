//
//  TableViewController.swift
//  OntheMap
//
//  Created by MUHAMMED ZOYED on 15/07/2020.
//  Copyright © 2020 Udacity. All rights reserved.
//

import UIKit

class TableViewController: UITableViewController {

    @IBOutlet var Table: UITableView!
    
    var userData = Data.shared.usersData
    
    var locations: [StudentLoc] = [] {
        didSet {
            Table.reloadData()
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        getUsers()
    }
    
    func getUsers(){
        Parse.sharedInstance().getStudentLocations(){(locations, success, error)in
            if success {
                guard let userLocation = locations else {return}
                self.userData = userLocation as [StudentLoc]
                DispatchQueue.main.async {
                    self.Table.reloadData()}
            }else{
                let alert = UIAlertController(title: "Erorr", message: "Failed Request", preferredStyle: .alert )
                    alert.addAction(UIAlertAction (title: "OK", style: .default, handler: { _ in
                        return
                }))
                self.present(alert, animated: true, completion: nil)
                return}
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()


    }


    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return userData.count
        
    }


    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 60
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "TableView") as! TableViewCell
        let data = self.userData[indexPath.row] as! StudentLoc
        


        cell.icon?.image = UIImage(named: "pin")
        let fullName = "\(data.firstName ?? "first name") \(data.lastName ?? "last name")"
        cell.name.text = fullName
        let mediaUrl = data.mediaURL
        cell.url.text = mediaUrl
        return cell
    }

    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let data = self.userData[indexPath.row] as! StudentLoc
        if let url =  URL(string: data.mediaURL!){
            if #available(iOS 10.0, *) {
                UIApplication.shared.open(url, options: [:])
            } else {
                // Fallback on earlier versions
            }
        }else{
            let alert = UIAlertController(title: "Erorr", message: "Failed open URL", preferredStyle: .alert )
            alert.addAction(UIAlertAction (title: "OK", style: .default, handler: { _ in
                return
            }))
            self.present(alert, animated: true, completion: nil)
        }
    }
    
    @IBAction func logout(_ sender: Any) {
            API.logout() { (success) in
                DispatchQueue.main.async {
                    if success {
                        self.tabBarController?.dismiss(animated: true, completion: nil)
                        
                    }else {
                        let alert = UIAlertController(title: "Erorr", message: "Error in Logout", preferredStyle: .alert )
                        alert.addAction(UIAlertAction (title: "OK", style: .default, handler: { _ in
                            return
                        }))
                        self.present(alert, animated: true, completion: nil)
                        return}
                }
        }
    }
    
    @IBAction func refresh(_ sender: Any) {
         getUsers()
    }
    
    

}
