//
//  studentLoc.swift
//  OntheMap
//
//  Created by MUHAMMED ZOYED on 7/12/20.
//  Copyright © 2020 Udacity. All rights reserved.
//

import Foundation
import UIKit

struct StudentLoc : Codable {
    
    static var Location = [StudentLoc]()
    
    var createdAt : String?
    var firstName : String?
    var lastName : String?
    var latitude : Double?
    var longitude : Double?
    var mapString : String?
    var mediaURL : String?
    var objectId : String?
    var uniqueKey : String?
    var updatedAt : String?
    
}
extension StudentLoc {
    init(mapString: String, mediaURL: String) {
        self.mapString = mapString
        self.mediaURL = mediaURL
    }
}
